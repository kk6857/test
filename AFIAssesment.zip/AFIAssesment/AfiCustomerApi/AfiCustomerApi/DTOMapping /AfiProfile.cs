﻿using System;
using AfiCustomerApi.Data.Models;
using AfiCustomerApi.DataTransferObject;
using AutoMapper;

namespace AfiCustomerApi.Profiles
{
    public class AfiProfile : Profile
    {
        public AfiProfile()
        {
            CreateMap<AfiCustomerDto, AfiCustomer>();
        }
    }
}
