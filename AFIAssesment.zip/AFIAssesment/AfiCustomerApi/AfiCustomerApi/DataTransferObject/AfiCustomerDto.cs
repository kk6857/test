﻿using System;
namespace AfiCustomerApi.DataTransferObject
{
    public class AfiCustomerDto
    {
        public int AfiCustomerID { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string PolicyReferenceNumber { get; set; }
        public DateTime? Dob { get; set; }
        public string Email { get; set; }
    }
}
