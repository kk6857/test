﻿using AfiCustomerApi.Data.Models;
using AfiCustomerApi.Services.Services;
using AutoFixture;
using System;
using System.Threading.Tasks;
using Xunit;

namespace AfiCustomerApiServicesTests.Services
{ 
    public class AfiCustomerValidationServiceTest
    {
        public readonly Fixture _fixture;
        public readonly IAfiCustomerValidationService _validationService;

        public static object[][] DatesData = {
        new Object[] { new DateTime(2021,01,01) , false },
        new Object[] { new DateTime(2020,02,02) , false },
        new Object[] { new DateTime(1990,03,03) , true },
        new Object[] { new DateTime(1995,04,04) , true },
        };

        public static object[][] EmailsData = {
        new Object[] { "abcd@ab.com", true },
        new Object[] { "abcd@ab.co.uk" , true },
        new Object[] { "abcd111@ab111.co.uk" , true },
        new Object[] { "abcd111@ab111.com" , true },
        new Object[] { "ab@ab.com", false },
        new Object[] { "a@a.com", false },
        new Object[] { "abcd111@ab111.in", false },
        };

        public static object[][] ReferenceNumberData = {
        new Object[] { "AB-123456", true },
        new Object[] { "BB-654321", true },
        new Object[] { "BB-12345", false },
        new Object[] { "BB-1234567", false },
        new Object[] { "ABC-123456", false },
        };


        public AfiCustomerValidationServiceTest()
        {
            _fixture = new Fixture();
            _validationService = new AfiCustomerValidationService();
        }

        [Fact]
        public async Task ValidateCustomerWithNullSurname()
        {
            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.SurName = null;

            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.False(result);
            
        }

        [Fact]
        public async Task ValidateCustomerWithNullFirstname()
        {
            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.FirstName = null;

            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.False(result);
        }

        [Fact]
        public async Task ValidateCustomerWithNullEmailandDob()
        {
            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.Email = null;
            customer.Dob = null;

            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.False(result);
        }
        
        [Theory, MemberData(nameof(ReferenceNumberData))]
        public async Task ValidateCustomerReferenceNumber(string policy, bool expected)
        {
            _fixture.Customize<AfiCustomer>(c =>
             c.With(p => p.FirstName, "Kshitij")
             .With(p => p.SurName, "Kumar")
             .With(p => p.Dob, DateTime.Now)
             .With(p => p.AfiCustomerID, 1)
             .With(p => p.PolicyReferenceNumber, "KK-123456")
             .With(p => p.Email, "kshitij@kumar.co.uk"));

            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.PolicyReferenceNumber = policy;
            customer.Dob = null;
            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.Equal(expected, result);
        }

        [Theory, MemberData(nameof(EmailsData))]
        public async Task ValidateCustomerEmail(string email, bool expected)
        {
            _fixture.Customize<AfiCustomer>(c =>
             c.With(p => p.FirstName, "Kshitij")
             .With(p => p.SurName, "Kumar")
             .With(p => p.Dob, DateTime.Now)
             .With(p => p.AfiCustomerID, 1)
             .With(p => p.PolicyReferenceNumber, "KK-123456")
             .With(p => p.Email, "kshitij@kumar.co.uk"));

            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.Email = email;
            customer.Dob = null;
            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.Equal(expected, result);
        }

        [Theory, MemberData(nameof(DatesData))]
        public async Task ValidateCustomerAge(DateTime dob, bool expected)
        {
            _fixture.Customize<AfiCustomer>(c =>
               c.With(p => p.FirstName, "Kshitij")
               .With(p => p.SurName, "Kumar")
               .With(p => p.Dob, DateTime.Now)
               .With(p => p.AfiCustomerID, 1)
               .With(p => p.PolicyReferenceNumber, "KK-123456")
               .With(p => p.Email, "kshitij@kumar.co.uk"));

            AfiCustomer customer = _fixture.Create<AfiCustomer>();
            customer.Email = null;
            customer.Dob = dob;
            var result = await _validationService.ValidateCustomerEntity(customer);

            Assert.Equal(expected, result);
        }
    }
}
