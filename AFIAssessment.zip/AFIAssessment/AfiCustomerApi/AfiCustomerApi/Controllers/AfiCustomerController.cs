﻿using System.Threading.Tasks;
using AfiCustomerApi.Data.Models;
using AfiCustomerApi.DataTransferObject;
using AfiCustomerApi.Services;
using AfiCustomerApi.Services.Services;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging;

namespace AfiCustomerApi.Controllers
{
    [ApiController]
    [Route("api/AfiCustomer")]
    public class AfiCustomerController : ControllerBase
    {
        
        private readonly IAfiCustomerService _afiCustomerService;
        private readonly IAfiCustomerValidationService _afiCustomerValidationService;
        private readonly IMapper _mapper;

        public AfiCustomerController(IAfiCustomerService afiCustomerService, IAfiCustomerValidationService afiCustomerValidationService, IMapper mapper)
        {
            _afiCustomerService = afiCustomerService;
            _afiCustomerValidationService = afiCustomerValidationService;
            _mapper = mapper;
        }

        [HttpPost]
        [Route("RegisterCustomer")]
        public async Task<ActionResult> RegisterCustomer([FromBody] AfiCustomerDto customerdto)
        {
            var customer = _mapper.Map<AfiCustomer>(customerdto);

            if (await _afiCustomerValidationService.ValidateCustomerEntity(customer))
            {
                var result = await _afiCustomerService.RegisterAfiCustomer(customer);
                if (result == -1)
                {
                    return StatusCode(500);
                }

                return Created("api/Customer",result.ToString());
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
